# ThinkPad T440 — Sway reference rice v11

This is the real NixOS/Home Manager build of the `r/unixporn` setup used as the
visual target: forest-wreck wallpaper, black content rectangles, no normal
panel, tiny edge text, qutebrowser as the reading interface, dunst, senpai, and
PxPlus IBM VGA8 everywhere it makes sense.

## Hardware target

- Lenovo ThinkPad T440
- Intel Core i5-4300U
- Intel HD 4400
- 4 GB RAM
- 500 GB SSD
- user: `sloth`, host: `thinkpad`

The repository **does not invent disk/partition data**. The included
`system/hardware-configuration.nix` is a deliberate safety placeholder.
`./prepare.sh` must replace it with the real file from this T440.

## What reproduces the reference

- Sway, not DWM; no Waybar/swaybar.
- Tiny top-left date/time and bottom-right `workspace FLOAT battery RAM` text.
- Lemonbar-Xft with **PxPlus IBM VGA8** (the exact font named by the reference
  author). The font comes from Nixpkgs; no font binary is bundled here.
- Qutebrowser with the recovered right-side numbered-tab and bottom in-mode
  statusbar settings.
- Dunst notifications and senpai IRC.
- Almost-black application surfaces, 1 px square borders, no rounded corners,
  no titlebars and no decorative desktop chrome.
- Exact reference wallpaper bundled at `user/wallpaper/773.jpg`.
- `Super+Shift+R` launches/repositions a reference-like workspace layout.

## Wallpaper-derived theme

`theme-sync` uses pywal16 to derive accents from the current wallpaper while
keeping application surfaces near black. It regenerates colors for:

- Sway borders
- Foot / Foot server clients
- qutebrowser
- Neovim
- dunst
- fuzzel
- tmux
- zathura
- Yazi
- GTK selection accents
- the two lemonbar-Xft edge readouts

Changing wallpaper is instant and **does not require a Nix rebuild**:

```sh
set-wallpaper ~/Pictures/something.png
```

`Super+W` opens a wallpaper chooser. Any input is normalized to a real JPEG in
`~/.local/share/rice/wallpaper.jpg`; your original image is not modified.

Reset to the bundled reference image:

```sh
theme-sync --reset-reference
```

## Safe first migration from the working v10

From the extracted/cloned v11 directory:

```sh
./prepare.sh
```

If automatic detection does not find the current config, pass it explicitly:

```sh
./prepare.sh ~/v10/v10-fixed
# or: ./prepare.sh ~/nixos-thinkpad-dwm
```

Then:

```sh
nix flake check
touch ~/.disable-gui
sudo nixos-rebuild test --flake .#thinkpad
```

Do **not** switch yet. Exit the currently running DWM session back to a tty and
start Sway manually:

```sh
theme-sync --startup
sway
```

Test Wi-Fi, Bluetooth, audio, touchpad/TrackPoint, brightness, suspend/resume,
qutebrowser, terminal apps, wallpaper switching, and the exit path. Then run:

```sh
rice-doctor
```

If it passes, exit Sway back to the tty with `Super+Shift+E`, then:

```sh
nix-apply
rm -f ~/.disable-gui ~/.disable-sway ~/.disable-x
sudo reboot
```

Keep `~/.disable-gui` present during the entire manual test. It does not block a
manual `sway` command; it only prevents automatic launch on tty1.

The Sway startup path deliberately contains **no `exec sway`, no `.xinitrc`, and
no `startx`**. If Sway exits or crashes, tty1 remains a shell instead of entering
the old restart/flicker loop.

## Core keys

| Key | Action |
|---|---|
| `Super+Enter` | Foot terminal |
| `Super+D` | fuzzel launcher |
| `Super+B` | qutebrowser |
| `Super+E` | Neovim |
| `Super+Y` | Yazi |
| `Super+X` | btop |
| `Super+M` | cmus |
| `Super+I` | senpai |
| `Super+R` | tremc + on-demand Transmission |
| `Super+W` | wallpaper chooser |
| `Super+Shift+W` | nmtui |
| `Super+Shift+B` | Bluetooth manager |
| `Super+Shift+A` | pulsemixer |
| `Super+Shift+F` | compact reference-style `rice-fetch` terminal |
| `Super+Space` / `Super+Shift+Space` | float/tile current window |
| `Super+C` | center current floating window |
| `Super+F` | fullscreen |
| `Super+H/J/K/L` | focus |
| `Super+Shift+H/J/K/L` | move |
| `Super+Ctrl+H/J/K/L` | resize |
| `Super+1..5` | workspaces |
| `Super+Shift+1..5` | move to workspace |
| `Super+Shift+R` | recreate reference layout |
| `Super+Ctrl+R` | reload Sway |
| `Super+Shift+N` | test dunst notification |
| `Super+Escape` | lock |
| `Super+Shift+S` | suspend |
| `Super+Shift+E` | confirmed exit to tty1 |
| `Print` | region screenshot -> clipboard |
| `Super+Print` | full screenshot -> `~/Pictures/Screenshots` |

## T440-specific fixes / resource choices

- Intel HD 4400 uses the Haswell `i965` VA-API path.
- 32-bit graphics remains enabled for Wine.
- 50% zram; v11 creates **no additional SSD swapfile**. Existing real swap is
  only whatever the T440 hardware configuration already defines.
- TLP + thermald + SSD TRIM.
- BAT0/BAT1 thresholds remain 40/80.
- The tiny status readout handles dual batteries without summing incompatible
  `energy_*` and `charge_*` units.
- systemd-boot keeps exactly three entries: current plus two previous generations.
- Tap-to-click and palm rejection are explicit in Sway.
- PipeWire defaults to a conservative 256-frame quantum; `audio-lowlatency`
  temporarily forces 128 and `audio-normal` clears the override. `reaper-pw`
  launches REAPER through PipeWire's JACK compatibility layer.
- Transmission is not a login service; the helper starts it only while tremc is
  being used.
- Foot server mode shares font/glyph state; `rice-foot` falls back to standalone
  Foot automatically if the server is unavailable.
- Home Manager backs up pre-existing managed files instead of aborting the
  activation.

## Git workflow

Once this directory is your real repo (recommended path `~/nixos-config`):

```sh
nix-sync
```

means:

```text
git pull --ff-only -> nix flake check -> nixos-rebuild test
```

After the test is good:

```sh
nix-apply
```

runs the config check, `rice-doctor`, and the permanent switch.

After `prepare.sh` succeeds, commit **both** `flake.lock` and the real
`system/hardware-configuration.nix`. That is what turns this into a pinned,
machine-specific restore point rather than just a theme archive.

## Recovery

At any tty:

```sh
touch ~/.disable-gui
```

prevents graphical autostart on the next tty1 login. v11 also honors the older
`~/.disable-sway` and `~/.disable-x` rescue files. Remove them only when you want
automatic Sway startup again.

See `VALIDATION.md` for what was checked before packaging and what still must be
validated by Nix on the actual T440.
