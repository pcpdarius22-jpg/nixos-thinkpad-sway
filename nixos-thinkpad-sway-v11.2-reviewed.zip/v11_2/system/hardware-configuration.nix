# This is a safety placeholder, not hardware data.
# Run ./prepare.sh on the actual ThinkPad T440 before evaluating the flake.
throw ''
  This is a safety placeholder. Copy the real ThinkPad T440
  system/hardware-configuration.nix into this repository first.
  Run: ./prepare.sh [path-to-current-config]
''
