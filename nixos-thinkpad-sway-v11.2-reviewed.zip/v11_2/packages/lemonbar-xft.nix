{ stdenv
, lib
, pkg-config
, libxcb
, libx11
, libxft
, fontconfig
, freetype
, zlib
, src
}:

stdenv.mkDerivation {
  pname = "lemonbar-xft";
  version = "1.1-xft-port";
  inherit src;

  nativeBuildInputs = [ pkg-config ];
  buildInputs = [
    libxcb
    libx11
    libxft
    fontconfig
    freetype
    zlib
  ];

  dontConfigure = true;

  # The T440 is a single-panel laptop. Xinerama is intentionally not enabled;
  # the fork guards it behind WITH_XINERAMA and RandR is sufficient here.
  buildPhase = ''
    runHook preBuild
    $CC -Wall -std=c99 -Os -DVERSION='"1.1-xft"' \
      $(pkg-config --cflags xcb xcb-randr x11 x11-xcb xft freetype2 fontconfig) \
      -o lemonbar lemonbar.c \
      $(pkg-config --libs xcb xcb-randr x11 x11-xcb xft freetype2 fontconfig) -lz
    runHook postBuild
  '';

  installPhase = ''
    runHook preInstall
    install -Dm755 lemonbar "$out/bin/lemonbar"
    runHook postInstall
  '';

  meta = {
    description = "Lightweight lemonbar fork with Xft/fontconfig support";
    homepage = "https://github.com/drscream/lemonbar-xft";
    license = lib.licenses.mit;
    platforms = lib.platforms.linux;
    mainProgram = "lemonbar";
  };
}
