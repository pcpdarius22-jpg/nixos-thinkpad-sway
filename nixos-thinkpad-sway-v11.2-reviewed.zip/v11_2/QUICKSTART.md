# v11 quick start — T440

This archive deliberately ships with a **hardware placeholder**. Do not run a
rebuild until `prepare.sh` copies the real hardware configuration from the
currently working T440 setup.

```sh
cd ~/path/to/nixos-thinkpad-sway-v11
./prepare.sh
nix flake check
```

For the first migration, keep graphical autostart disabled while testing:

```sh
touch ~/.disable-gui
sudo nixos-rebuild test --flake .#thinkpad
```

Exit the current DWM session to a TTY, then launch v11 manually:

```sh
theme-sync --startup
sway
```

Inside Sway, test the laptop and run:

```sh
rice-doctor
```

`Super+Shift+R` builds the reference screenshot-style workspace.
`Super+Shift+E` safely exits Sway back to the TTY.

Only after the manual test is good:

```sh
nix-apply
rm -f ~/.disable-gui ~/.disable-sway ~/.disable-x
sudo reboot
```

The reference forest-wreck wallpaper is bundled at `user/wallpaper/773.jpg` and
becomes the default automatically. `Super+W` changes wallpapers later without a
Nix rebuild.
