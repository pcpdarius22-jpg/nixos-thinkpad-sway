{
  description = "ThinkPad T440 NixOS 26.05 — Sway reference rice v11";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-26.05";

    home-manager = {
      url = "github:nix-community/home-manager/release-26.05";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    # The original rice uses PxPlus IBM VGA8 in lemonbar. Stock lemonbar uses
    # X core fonts; this small fork adds Xft/fontconfig so the exact TTF works.
    lemonbar-xft-src = {
      url = "github:drscream/lemonbar-xft/xft-port";
      flake = false;
    };
  };

  outputs = { nixpkgs, home-manager, lemonbar-xft-src, ... }: {
    nixosConfigurations.thinkpad = nixpkgs.lib.nixosSystem {
      system = "x86_64-linux";
      modules = [
        ./system/configuration.nix
        ./system/audio.nix
        home-manager.nixosModules.home-manager
        {
          home-manager.useGlobalPkgs = true;
          home-manager.useUserPackages = true;
          home-manager.backupFileExtension = "v11-backup";
          home-manager.overwriteBackup = true;
          home-manager.extraSpecialArgs = { inherit lemonbar-xft-src; };
          home-manager.users.sloth = import ./user/home.nix;
        }
      ];
    };
  };
}
