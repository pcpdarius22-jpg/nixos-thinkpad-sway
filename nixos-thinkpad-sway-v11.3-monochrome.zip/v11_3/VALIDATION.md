# v11.3 validation notes

Static checks completed before packaging:

- all shell scripts pass `bash -n`;
- generated qutebrowser Python compiles;
- generated Yazi TOML parses;
- generated Waybar multi-bar JSON parses with `jq`;
- wallpaper decodes and normalizes with ImageMagick;
- no lemonbar source/input/package remains;
- no pywal/wallpaper-derived palette logic remains;
- no Sway `default_border pixel` or colored focus-border path remains;
- no duplicate exact Sway key combinations were found by the local checker;
- archive integrity is tested after ZIP creation.

Hardware/runtime validation still belongs on the real T440. Required sequence:

```sh
./prepare.sh ~/v11-test/v11_2
nix flake check
sudo nixos-rebuild test --flake .#thinkpad
rice-doctor
```

Then launch `theme-sync --startup` and `sway` manually. Do not use `switch`
until PxPlus, the transparent edge text, qutebrowser, hardware keys, suspend,
Wi-Fi/Bluetooth and the clean Sway exit path all work.
